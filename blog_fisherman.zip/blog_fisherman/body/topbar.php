<!--Ici on trouve la barre de navigation, le logo de Blog FisherMan-->
<nav class="cyan darken-3">
    <div class="container">
        <div class="nav-wrapper">
            <a href="index.php?page=home" class="brand-logo"><img class="responsive-img" src="http://51.255.196.206/edouard/blog-fisherman//img/logo.png"></a>

            <a href="#" data-activates="mobile-menu" class="button-collapse"><i class="material-icons">menu</i></a>

            <ul class="right hide-on-med-and-down">
                <li class="<?php echo ($page=="home")?"active" : ""; ?>"><a href="index.php?page=home">Accueil</a></li>
                <li class="<?php echo ($page=="blog")?"active" : ""; ?>"><a href="index.php?page=blog">Blog</a></li>
                
                <!-- Dropdown Trigger -->
    <a class='dropdown-button btn  amber darken-3' href='#' data-activates='dropdown1'>Menu</a>

  <!-- Dropdown Structure -->
    <ul id='dropdown1' class='dropdown-content'>
    <li><a href="admin/index.php"><i class="material-icons">perm_identity</i><br>Connexion</a></li>
    <li class="divider"></li>
    <li><a href="#"><i class="material-icons">info_outline</i><br>A propos</a></li>
    <li class="divider"></li>
    <li><a href="#"><i class="material-icons ">contacts</i><br>Contact</a></li>
  </ul>
        
                                   
            </ul>

            <ul class="side-nav" id="mobile-menu">
                <li class="<?php echo ($page=="home")?"active" : ""; ?>"><a href="index.php?page=home">Accueil</a></li>
                <li class="<?php echo ($page=="blog")?"active" : ""; ?>"><a href="index.php?page=blog">Blog</a></li>
            </ul>

        
    </div>    
   
        
        </nav>
