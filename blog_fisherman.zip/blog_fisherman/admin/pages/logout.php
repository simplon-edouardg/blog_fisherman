<?php
    unset($_SESSION['admin']);
    header("Location:../");