<?php
//On inclu la fonction 
    include 'functions/main-functions.php';

    $pages = scandir('pages/');
    if(isset($_GET['page']) && !empty($_GET['page'])){
        if(in_array($_GET['page'].'.php',$pages)){
            $page = $_GET['page'];
        }else{
            $page = "error";
        }
    }else{
        $page = "home";
    }

    $pages_functions = scandir('functions/');
    if(in_array($page.'.func.php',$pages_functions)){
        include 'functions/'.$page.'.func.php';
    }

?>


<!DOCTYPE html>
<html>
    <head>
<!--On charge les fonts (Roboto et les icones), Materialize (le framwork CSS)-->
        <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link type="text/css" rel="stylesheet" href="css/materialize.css"  media="screen,projection"/>
        <title>Blog FisherMan / Le Blog du Pêcheur</title>
        <description>BlogFisherMan est un petit blog pour les pêcheurs de la côte Méditérranéenne du Grand Narbonne, de Fleury jusqu'à Leucate, en passant par Narbonne Plage, Gruissan, Peyriac de Mer, Sigean, etc ...</description>
        <meta lang="fr"/>
        <meta charset="utf-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    </head>

    <body>
		
		
<!--On inclu la barre de menu et le slider juste en dessous-->
        <?php
            include "body/topbar.php";
        ?>
<!--On charge le container principal du blog, c'est lui qui encadre toutes les DIV du contenu, grâce à MaterializeCSS-->
				<div clas="container">           
          
<!--On charge le Slider Pleine Largeur, les class sont natives à Materialize, on peut en ajouter tant qu'on veut, ça fait joli et j'aime bien-->
               <div class="slider">
    <ul class="slides">
      <li>
        <img src="img/sliders/truite_1.jpg"> <!-- image slide 1 -->
        <div class="caption left-align">
          <h3>La Pêche à la Truite !</h3>
          <h5 class="light grey-text text-lighten-3">Truite Fario en rivière..</h5>
        </div>
      </li>
      <li>
        <img src="img/sliders/couteaux_1.jpg"> <!-- image slide 2 -->
        <div class="caption left-align">
          <h3>La Pêche à Pieds !</h3>
          <h5 class="light grey-text text-lighten-3">Couteaux : Les techniques de Pêche ...</h5>
        </div>
      </li>
      <li>
        <img src="img/sliders/digue_1.jpg"> <!-- image slide 3 -->
        <div class="caption left-align">
          <h3>Pêcher au bord d'une Digue !</h3>
          <h5 class="light grey-text text-lighten-3">Bien réaliser son montage ...</h5>
        </div>
      </li>
      <li>
        <img src="img/sliders/waiders_1.jpg"> <!-- image slide 4 -->
        <div class="caption center-align">
          <h3>Pêcher les pieds dans l'eau !</h3>
          <h5 class="light grey-text text-lighten-3">Le Waiders pour aller plus loin ...</h5>
        </div>
      </li>
	<li>
		<img src="img/sliders/truite-2.jpg"> <!-- image slide 5 -->
        <div class="caption right-align">
          <h3>La Pêche à La Mouche !</h3>
          <h5 class="light grey-text text-lighten-3">Le Matériel spécifique et adapté ...</h5>
        </div>
      </li>
	<li>
        <img src="img/sliders/surfkasting_1.jpg"> <!-- image slide 6 -->
        <div class="caption left-align">
          <h3>Pêcher au bord de La Plage !</h3>
          <h5 class="light grey-text text-lighten-3">Qu'est-ce que le SurfKasting? ...</h5>
        </div>
      </li>
    </ul>
  </div>

<!--Ici se charge le contenu dynamique, les pages se chargent dans l'index en fonction de la requête utilisateur, exemple une page blog ou l'index, sinon page Error-->
        <div class="container">
            <?php
                include 'pages/'.$page.'.php';
            ?>
			
					
        </div>
        
         
        <!--On importe le jQuery, materialize.js, le Js et des fonctions relatives au scan des pages, sinon page Error-->
        <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
        <script type="text/javascript" src="js/materialize.js"></script>
        <script type="text/javascript" src="js/script.js"></script>
        <?php
            $pages_js = scandir('js/');
            if(in_array($page.'.func.js',$pages_js)){
                ?>
                    <script type="text/javascript" src="js/<?= $page ?>.func.js"></script>
                <?php
            }

        ?>

    </body>
</html>